package registro;

public class Credencial {
	private String username;
	private String password;
	private String secuencia;
	
	public Credencial(String username, String password, String secuencia) {
		super();
		this.username = username;
		this.password = password;
		this.secuencia = secuencia;
	}
	
	public boolean comprobarPassword(String password) {
		boolean correcto=false;
		
		if(this.password.equals(password)) {
			correcto=true;
		}
		
		return correcto;
	}

	public String getUsername() {
		return username;
	}
	
	public boolean esPasswordSegura() {
		boolean seguro=false;
		
		for (int i = 0; i<= password.length(); i++){
			if(Character.isUpperCase(password.charAt(i))&& Character.isLowerCase(password.charAt(i)) ){
				seguro=true;
			}
		}
		return seguro;
	}

	public void setPassword(String newpass) {
		this.password = newpass;
	}
}
