package registro;
import java.util.Scanner;
public class Principal {
	public static void main(String[] argsw) {
		
		Scanner sc=new Scanner(System.in);
		String nombre=null;
		String apellidos=null;
		String email = null;
		Credencial credencial = null;
		Usuario [] usuarios=new Usuario[10];
		Usuario usuario=null;
		String username=null;
		String password = null;
		boolean cambiar;
		
		int i=0;
		
		while(i>usuarios.length && usuarios[i]!=null && i<=10) {
			i++;
			
			if(usuario.equals(usuarios[i])) {
				usuario.hacerLogin(username, password);
				System.out.println(usuario.esCuentaBloqueada());
				if(usuario.esCuentaBloqueada()==false) {
					System.out.println(usuario.esPasswordSegura());
					cambiar=sc.hasNext();
					if(cambiar==true) {
						usuario.modificarPassword(email, username, password);
					}
				}
				
				
			}else {
				System.out.println("Escriva su nombre");
				nombre=sc.next();
		
				System.out.println("Escriva sus apellidos");
				apellidos=sc.next();
				
				 int digito=100;
				
				username= nombre + apellidos + digito++;
				
				
			}
		}
		
		
		
		
	}
}
