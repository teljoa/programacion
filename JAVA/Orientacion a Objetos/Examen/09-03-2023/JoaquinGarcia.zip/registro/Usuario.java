package registro;

public class Usuario {

	private String nombre;
	private String apellidos;
	private String email;
	private int intentos;
	private Credencial credencial;
	private static final int NMaximo=2;
	
	public Usuario(String nombre, String apellidos, Credencial credencial) {
		super();
		this.nombre = nombre;
		this.apellidos = apellidos;
		this.credencial = credencial;
	}
	
	public Usuario(String nombre, String apellidos,String email,Credencial credencial) {
		this.nombre=nombre;
		this.apellidos=apellidos;
		this.email=email;
		this.credencial=credencial;
	}
	

	public boolean esCuentaBloqueada() {
		boolean bloqueo=false;
		
		if(intentos>=NMaximo) {
			bloqueo=true;
		}
		
		return bloqueo;
	}
	
	private void setPassword(Credencial credencial) {
		this.credencial = credencial;
	}
	
	public boolean modificarPassword(String oldpass, String newpass, String newpassverif) {
		boolean nueva=false;
		
		if(oldpass.equalsIgnoreCase(newpass) && newpass.equals(newpassverif)) {
			nueva=true;
		}
		
		return nueva;
	}
	
	public boolean esPasswordSegura() {
		boolean segura=false;
		
		if(credencial.esPasswordSegura()) {
			segura=true;
		}
		
		return segura;
	}
	
	public boolean hacerLogin(String username, String password) {
		boolean entra=false;
		
		if(username.equals(username)&& password.equals(password)) {
			entra=true;
		}
		
		return entra;
	}
}
